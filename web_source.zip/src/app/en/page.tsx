"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import type { CSSProperties } from "react";
import Link from "next/link";
import "@/components/en/en.css";
import { db } from "@/lib/db";
import { EN_WORLDS } from "@/lib/en/words";
import { getEnStatus, loadEnWords } from "@/lib/en/vocab";
import { countDue } from "@/lib/en/store";
import { dayKey } from "@/lib/tower";
import { STAGE_SIZE, buildStages, stageStates, type Prog, type StageState } from "@/lib/en/map";

// Màu từng thế giới (nền, viền đáy cho cảm giác nổi khối)
const WORLD_THEME = [
  { bg: "#10936f", edge: "#06503d" },
  { bg: "#e0456b", edge: "#9f1239" },
  { bg: "#3b82c4", edge: "#1e4f86" },
  { bg: "#d9a23a", edge: "#8a5a0b" },
  { bg: "#8b5cb0", edge: "#4c2a6b" },
];
const themeOf = (world: number) => WORLD_THEME[(world - 1) % WORLD_THEME.length];

const TOOLS = [
  { href: "/en/vocab", icon: "M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253", label: "Từ vựng" },
  { href: "/en/review", icon: "M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15", label: "Ôn tập" },
  { href: "/en/listen", icon: "M3 14v-2a9 9 0 0118 0v2M3 14h3a1 1 0 011 1v4a1 1 0 01-1 1H5a2 2 0 01-2-2v-4zm18 0h-3a1 1 0 00-1 1v4a1 1 0 001 1h1a2 2 0 002-2v-4z", label: "Nghe" },
  { href: "/en/speak", icon: "M12 14a3 3 0 003-3V6a3 3 0 10-6 0v5a3 3 0 003 3zM5 11a7 7 0 0014 0M12 18v3", label: "Nói" },
  { href: "/en/games", icon: "M7 9h4M9 7v4M16 10h.01M18 12h.01M6 6h12a4 4 0 014 4v3a4 4 0 01-4 4h-1.5l-2-2h-5l-2 2H6a4 4 0 01-4-4v-3a4 4 0 014-4z", label: "Trò chơi" },
  { href: "/en/skills", icon: "M5 20V12M12 20V5M19 20v-9", label: "Kỹ năng" },
];

function ToolIcon({ d }: { d: string }) {
  return (
    <svg className="en-tool-ico" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <path d={d} />
    </svg>
  );
}

const NODE = 76;
const BOSS = 90;

// Đường đi uốn lượn kiểu 0, 44, 62, 44, 0, -44, -62, -44 (px)
function offsetOf(n: number, boss: boolean) {
  if (boss) return 0;
  return Math.round(Math.sin(((n - 1) * Math.PI) / 4) * 62);
}

function IconCheck() {
  return (
    <svg viewBox="0 0 24 24" width="38" height="38" aria-hidden="true">
      <path d="M5 12.5l4.5 4.5L19 7.5" fill="none" stroke="currentColor" strokeWidth="3.6" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}
function IconStar({ size = 38, color = "currentColor" }: { size?: number; color?: string }) {
  return (
    <svg viewBox="0 0 24 24" width={size} height={size} aria-hidden="true">
      <polygon
        points="12,2.5 14.9,8.7 21.6,9.5 16.6,14.1 18,20.8 12,17.4 6,20.8 7.4,14.1 2.4,9.5 9.1,8.7"
        fill={color}
        stroke={color}
        strokeWidth="1.6"
        strokeLinejoin="round"
      />
    </svg>
  );
}
function IconLock() {
  return (
    <svg viewBox="0 0 24 24" width="32" height="32" aria-hidden="true">
      <rect x="6" y="11" width="12" height="9" rx="2.2" fill="currentColor" />
      <path d="M8.5 11V8a3.5 3.5 0 017 0v3" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" />
    </svg>
  );
}
function IconTrophy({ size = 42 }: { size?: number }) {
  return (
    <svg viewBox="0 0 24 24" width={size} height={size} aria-hidden="true">
      <path d="M7 4h10v4a5 5 0 01-10 0V4z" fill="currentColor" />
      <path d="M7 6H4.6a2.6 2.6 0 002.9 3.3M17 6h2.4a2.6 2.6 0 01-2.9 3.3" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" />
      <rect x="11" y="13" width="2" height="4" fill="currentColor" />
      <rect x="8" y="17" width="8" height="3" rx="1.2" fill="currentColor" />
    </svg>
  );
}

// Linh vật: nửa quả dưa hấu, đứng cạnh chặng hiện tại
function Mascot() {
  return (
    <svg viewBox="0 0 100 100" width="76" height="76" aria-hidden="true">
      <path d="M50 44c-1-9-7-14-14-14 1 8 7 13 14 14z" fill="#22c55e" />
      <path d="M50 44c1-9 7-14 14-14-1 8-7 13-14 14z" fill="#16a34a" />
      <path d="M8 46a42 42 0 0084 0z" fill="#15803d" />
      <path d="M12 46a38 38 0 0076 0z" fill="#f0fdf4" />
      <path d="M15 46a35 35 0 0070 0z" fill="#fb7185" />
      <ellipse cx="38" cy="60" rx="4.6" ry="5.4" fill="#3f1d2b" />
      <ellipse cx="62" cy="60" rx="4.6" ry="5.4" fill="#3f1d2b" />
      <circle cx="39.6" cy="58" r="1.6" fill="#fff" />
      <circle cx="63.6" cy="58" r="1.6" fill="#fff" />
      <circle cx="29" cy="68" r="4.4" fill="#f43f5e" opacity="0.45" />
      <circle cx="71" cy="68" r="4.4" fill="#f43f5e" opacity="0.45" />
      <path d="M44 68q6 7 12 0" fill="none" stroke="#3f1d2b" strokeWidth="2.6" strokeLinecap="round" />
      <ellipse cx="50" cy="52" rx="1.7" ry="2.6" fill="#3f1d2b" opacity="0.55" />
    </svg>
  );
}

function SmallStars({ n }: { n: number }) {
  return (
    <div
      className="absolute left-1/2 flex -translate-x-1/2 gap-0.5 rounded-full px-2 py-1"
      style={{ bottom: -20, background: "linear-gradient(180deg,#fffefb,#fff3d6)", boxShadow: "0 0 0 1px rgba(176,136,60,.4), 0 8px 12px -6px rgba(110,70,20,.45)" }}
      aria-label={`${n} sao`}
    >
      {[1, 2, 3].map((i) => (
        <IconStar key={i} size={15} color={i <= n ? "#e0a526" : "#e8dcc6"} />
      ))}
    </div>
  );
}

function Ring({ pct }: { pct: number }) {
  const r = 34;
  const c = 2 * Math.PI * r;
  return (
    <div className="relative shrink-0" style={{ width: 92, height: 92 }} role="img" aria-label={`Đã học ${pct}%`}>
      <svg viewBox="0 0 92 92" width="92" height="92" aria-hidden="true">
        <circle cx="46" cy="46" r={r} fill="none" stroke="rgba(255,255,255,0.18)" strokeWidth="8" />
        <circle
          cx="46"
          cy="46"
          r={r}
          fill="none"
          stroke="#f2cf75"
          strokeWidth="8"
          strokeLinecap="round"
          strokeDasharray={`${(c * pct) / 100} ${c}`}
          transform="rotate(-90 46 46)"
        />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center leading-none">
        <span style={{ fontFamily: "var(--serif)", fontSize: 24, fontWeight: 700 }}>{pct}</span>
        <span style={{ fontSize: 10, opacity: 0.75, marginTop: 2 }}>phần trăm</span>
      </div>
    </div>
  );
}

interface Group {
  world: number;
  items: StageState[];
}

export default function EnMapPage() {
  const [states, setStates] = useState<StageState[] | null>(null);
  const [hint, setHint] = useState<string | null>(null);
  const [open, setOpen] = useState<Record<number, boolean>>({});
  const [dueN, setDueN] = useState(0);
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    let alive = true;
    (async () => {
      const words = await loadEnWords();
      const stages = buildStages(words);
      const progress: Record<string, Prog> = {};
      try {
        const rows = await db.en_progress.toArray();
        for (const r of rows) {
          progress[r.stage_id] = {
            stars: r.stars,
            doneOn: r.done_on,
            used: !!r.used,
            recalled: !!r.recalled,
            recallOn: r.recall_on,
          };
        }
      } catch {
        // chưa đọc được dữ liệu trong máy: coi như chưa có tiến độ
      }
      let dueCount = 0;
      try {
        dueCount = await countDue();
      } catch {
        // chưa đọc được thẻ ôn trong máy
      }
      if (alive) {
        setDueN(dueCount);
        setStates(stageStates(stages, progress, dayKey(new Date())));
      }
    })();
    return () => {
      alive = false;
    };
  }, []);

  useEffect(() => {
    if (states) document.getElementById("en-current")?.scrollIntoView({ block: "center" });
  }, [states]);

  useEffect(() => {
    return () => {
      if (timer.current) clearTimeout(timer.current);
    };
  }, []);

  const groups = useMemo<Group[] | null>(() => {
    if (!states) return null;
    const out: Group[] = [];
    for (const s of states) {
      const last = out[out.length - 1];
      if (last && last.world === s.stage.world) last.items.push(s);
      else out.push({ world: s.stage.world, items: [s] });
    }
    return out;
  }, [states]);

  function showHint(id: string) {
    setHint(id);
    if (timer.current) clearTimeout(timer.current);
    timer.current = setTimeout(() => setHint(null), 2200);
  }

  if (!states || !groups) {
    return <p className="py-20 text-center text-sm text-stone-500">Đang dựng bản đồ...</p>;
  }

  const today = dayKey(new Date());
  const totalStars = states.reduce((a, s) => a + s.stars, 0);
  const due = states.filter((s) => s.recallDue);
  const recalledToday = states.filter((s) => s.prog?.recallOn === today).length;
  const learnedToday = states.some((s) => s.prog?.doneOn === today);
  const cur = states.find((s) => s.current);
  const normal = states.filter((s) => !s.stage.boss);
  const wordsTotal = normal.reduce((a, s) => a + s.stage.wordIds.length, 0);
  const wordsLearned = normal.filter((s) => s.stars > 0).reduce((a, s) => a + s.stage.wordIds.length, 0);
  const pct = wordsTotal > 0 ? Math.round((wordsLearned / wordsTotal) * 100) : 0;
  const st = getEnStatus();
  const srcText =
    st.source === "seed"
      ? `Đang dùng ${st.count} từ mẫu vì chưa đọc được bảng từ vựng: ${st.detail}`
      : `Từ vựng: ${st.count} từ${st.source === "cache" ? " (bản lưu trong máy)" : " từ Supabase"}.${
          st.detail ? ` Ghi chú: ${st.detail}.` : ""
        }${st.noVi > 0 ? ` ${st.noVi} từ chưa có nghĩa tiếng Việt, đang hiện định nghĩa tiếng Anh.` : ""}`;

  const card = "en-card p-4";
  const curWorld = cur ? EN_WORLDS.find((x) => x.id === cur.stage.world) : undefined;

  return (
    <main className="mx-auto w-full max-w-4xl pb-20 pt-2">
      <section className="en-hero">
        <div className="relative z-10 flex items-start justify-between gap-4">
          <div className="min-w-0">
            <p className="en-eyebrow">Hành trình tiếng Anh</p>
            <h1 className="en-hero-title mt-1">
              {cur ? `Chặng ${cur.stage.n}${curWorld ? ` · ${curWorld.name}` : ""}` : "Bạn đã đi hết bản đồ"}
            </h1>
            <p className="mt-1.5 text-sm text-white/80">
              {wordsLearned}/{wordsTotal} từ · {totalStars} sao
            </p>
          </div>
          <Ring pct={pct} />
        </div>

        <div className="relative z-10 mt-4 space-y-2">
          {due.length + recalledToday > 0 && (
            <Link
              href={due[0] ? `/en/stage/${due[0].stage.id}?recall=1` : "/en"}
              className={`en-task ${due.length === 0 ? "en-task--done" : ""}`}
            >
              <span>
                {due.length === 0 ? "✅" : "⬜"} Ôn lại bài hôm trước, không gợi ý
              </span>
              <span className="text-xs opacity-80">
                {recalledToday}/{recalledToday + due.length}
              </span>
            </Link>
          )}
          <Link href={cur ? `/en/stage/${cur.stage.id}` : "/en"} className={`en-task ${learnedToday ? "en-task--done" : ""}`}>
            <span>
              {learnedToday ? "✅" : "⬜"} Học {STAGE_SIZE} từ mới và dùng ngay trong câu
            </span>
            <span className="text-xs opacity-80">{learnedToday ? "1/1" : "0/1"}</span>
          </Link>
        </div>

        {cur && (
          <Link
            href={due[0] && !learnedToday ? `/en/stage/${due[0].stage.id}?recall=1` : `/en/stage/${cur.stage.id}`}
            className="en-btn en-btn--gold relative z-10 mt-4"
          >
            {due[0] && !learnedToday ? "Ôn lại trước, rồi học tiếp" : "Tiếp tục học"}
          </Link>
        )}

        <div className="en-tools relative z-10 lg:hidden">
          {TOOLS.map((t) => (
            <Link key={t.href} href={t.href} className="en-tool">
              <ToolIcon d={t.icon} />
              {t.label}
              {t.href === "/en/review" && dueN > 0 && <span className="en-badge">{dueN}</span>}
            </Link>
          ))}
        </div>
      </section>

      <div className="grid gap-8 lg:grid-cols-[minmax(0,1fr)_300px]">
        <section className="mx-auto w-full max-w-[420px]">
          {groups.map((g, gi) => {
            const w = EN_WORLDS.find((x) => x.id === g.world);
            const t = themeOf(gi + 1);
            const done = g.items.filter((s) => s.stars > 0).length;
            const forced = g.items.some((s) => s.current) || (!cur && gi === groups.length - 1);
            const shown = open[g.world] ?? forced;
            return (
              <div key={`w${g.world}`} className="mb-6">
                <button
                  type="button"
                  onClick={() => setOpen({ ...open, [g.world]: !shown })}
                  aria-expanded={shown}
                  className="en-world"
                  style={{ "--w1": t.bg, "--w2": t.edge } as CSSProperties}
                >
                  <div className="flex items-center justify-between gap-3">
                    <div>
                      <p className="relative z-10 text-[11px] font-bold uppercase tracking-[0.18em] text-white/80">
                        Phần {gi + 1} · {w?.tag}
                      </p>
                      <h2 className="relative z-10">
                        {w?.emoji} {w?.name}
                      </h2>
                    </div>
                    <span className="en-world-pill">
                      {done}/{g.items.length} {shown ? "▴" : "▾"}
                    </span>
                  </div>
                </button>

                <div className="pt-12" hidden={!shown}>
                  {shown && g.items.map((s) => {
                    const boss = s.stage.boss;
                    const size = boss ? BOSS : NODE;
                    const x = offsetOf(s.stage.n, boss);
                    const th = t;
                    const isDone = s.unlocked && s.stars > 0;
                    const kind = !s.unlocked ? "locked" : isDone ? "done" : "current";
                    const href = s.recallDue ? `/en/stage/${s.stage.id}?recall=1` : `/en/stage/${s.stage.id}`;
                    const faceStyle: CSSProperties | undefined =
                      kind === "current" ? ({ "--face": th.bg, "--edge": th.edge } as CSSProperties) : undefined;
                    const cls = `en-node en-node--${kind}`;
                    const icon =
                      kind === "locked" ? (
                        boss ? <IconTrophy /> : <IconLock />
                      ) : boss ? (
                        <IconTrophy />
                      ) : kind === "done" ? (
                        <IconCheck />
                      ) : (
                        <IconStar />
                      );
                    const off = x >= 0 ? -118 : 118;

                    return (
                      <div
                        key={s.stage.id}
                        id={s.current ? "en-current" : undefined}
                        className="relative flex justify-center"
                        style={{ marginBottom: 42, marginTop: s.current ? 40 : 0 }}
                      >
                        <div className="relative" style={{ transform: `translateX(${x}px)`, width: size, height: size }}>
                          {s.current && (
                            <div className="absolute left-1/2 z-10 -translate-x-1/2" style={{ bottom: size + 18 }}>
                              <Link href={`/en/stage/${s.stage.id}`} className="en-bubble en-bob" style={{ color: th.edge }}>
                                BẮT ĐẦU
                              </Link>
                            </div>
                          )}
                          {s.recallDue && (
                            <Link
                              href={href}
                              className="absolute left-1/2 z-10 -translate-x-1/2 whitespace-nowrap rounded-full px-3 py-1 text-[11px] font-bold uppercase tracking-wider text-[#3b2a05]"
                              style={{ bottom: size + 12, background: "linear-gradient(180deg,#f7dc8a,#d9a23a)", boxShadow: "0 0 0 1px rgba(150,105,20,.7), 0 8px 12px -6px rgba(150,105,20,.7)" }}
                            >
                              Ôn lại
                            </Link>
                          )}
                          {kind === "locked" && hint === s.stage.id && (
                            <div className="absolute left-1/2 z-20 -translate-x-1/2" style={{ bottom: size + 18 }}>
                              <div className="en-bubble text-stone-500" style={{ letterSpacing: 0, fontWeight: 700 }}>
                                Hoàn thành chặng trước để mở khóa
                              </div>
                            </div>
                          )}

                          {kind === "locked" ? (
                            <button
                              type="button"
                              onClick={() => showHint(s.stage.id)}
                              aria-label="Chặng đang khóa"
                              className={`${cls} ${hint === s.stage.id ? "en-shake" : ""}`}
                              style={{ width: size, height: size }}
                            >
                              {icon}
                            </button>
                          ) : (
                            <Link
                              href={kind === "current" ? `/en/stage/${s.stage.id}` : href}
                              aria-label={boss ? "Chặng boss" : `Chặng ${s.stage.n}`}
                              className={cls}
                              style={{ ...faceStyle, width: size, height: size }}
                            >
                              {kind === "current" && <span className="en-ring" />}
                              {icon}
                            </Link>
                          )}
                          {isDone && <SmallStars n={s.stars} />}
                        </div>

                        {s.current && (
                          <div
                            className="pointer-events-none absolute"
                            style={{ left: `calc(50% + ${off}px - 38px)`, top: "50%", marginTop: -38 }}
                          >
                            <div className="en-bob">
                              <Mascot />
                            </div>
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>
            );
          })}
        </section>

        <aside className="space-y-4 lg:sticky lg:top-24 lg:self-start">
          <div className={card}>
            <h2 className="mb-3 text-base font-extrabold text-stone-800">Tiến độ</h2>
            <div className="mb-2 flex items-baseline justify-between text-sm">
              <span className="font-bold text-stone-700">
                {wordsLearned}/{wordsTotal} từ
              </span>
              <span className="font-extrabold text-amber-600">{totalStars} ⭐</span>
            </div>
            <div className="en-track">
              <div className="en-fill" style={{ width: `${pct}%` }} />
            </div>
            <p className="mt-3 text-xs leading-relaxed text-stone-500">{srcText}</p>
          </div>

          <div className={`${card} max-lg:hidden`}>
            <h2 className="mb-3 text-base font-extrabold text-stone-800">Luyện tập</h2>
            <div className="grid grid-cols-2 gap-3">
              {TOOLS.map((t, k) => (
                <Link
                  key={t.href}
                  href={t.href}
                  className={`en-tool-card ${
                    k === TOOLS.length - 1 && TOOLS.length % 2 === 1 ? "col-span-2" : ""
                  }`}
                >
                  <ToolIcon d={t.icon} />
                  {t.label}
                  {t.href === "/en/review" && dueN > 0 && (
                    <span className="en-badge">{dueN}</span>
                  )}
                </Link>
              ))}
            </div>
          </div>
        </aside>
      </div>
    </main>
  );
}
